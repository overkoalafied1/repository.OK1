# script.module.covenant
Covenant Module Development - Kodi is a registered trademark of the XBMC Foundation. We are not connected to or in any other way affiliated with Kodi - DMCA: marty.mcgibbins@vfemail.net
